import WebFetchPage from '@/components/app/web-fetch-page';

export default function Home() {
  return <WebFetchPage />;
}
